package ui;

public class MainGui {
    public static void main(String[] args) {
        new LoadingScreen();
    }

}
